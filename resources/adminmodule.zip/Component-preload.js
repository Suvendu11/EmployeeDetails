//@ui5-bundle adminmodule/Component-preload.js
sap.ui.require.preload({
	"adminmodule/Component.js":function(){
sap.ui.define(["sap/ui/core/UIComponent","sap/ui/Device","adminmodule/model/models"],function(e,i,t){"use strict";return e.extend("adminmodule.Component",{metadata:{manifest:"json"},init:function(){e.prototype.init.apply(this,arguments);this.getRouter().initialize();this.setModel(t.createDeviceModel(),"device")}})});
},
	"adminmodule/controller/App.controller.js":function(){
sap.ui.define(["sap/ui/core/mvc/Controller"],function(n){"use strict";return n.extend("adminmodule.controller.App",{onInit:function(){}})});
},
	"adminmodule/controller/Master.controller.js":function(){
sap.ui.define(["sap/ui/core/mvc/Controller"],function(n){"use strict";return n.extend("adminmodule.controller.Master",{onInit:function(){}})});
},
	"adminmodule/i18n/i18n.properties":'# This is the resource bundle for adminmodule\n\n#Texts for manifest.json\n\n#XTIT: Application name\nappTitle=Employee Details\n\n#YDES: Application description\nappDescription=An SAP Fiori application.\n#XTIT: Main view title\ntitle=Employee Details',
	"adminmodule/manifest.json":'{"_version":"1.59.0","sap.app":{"id":"adminmodule","type":"application","i18n":"i18n/i18n.properties","applicationVersion":{"version":"0.0.1"},"title":"{{appTitle}}","description":"{{appDescription}}","resources":"resources.json","sourceTemplate":{"id":"@sap/generator-fiori:basic","version":"1.13.2","toolsId":"b983af63-f320-4aec-9cad-436bbc1d292d"}},"sap.ui":{"technology":"UI5","icons":{"icon":"","favIcon":"","phone":"","phone@2":"","tablet":"","tablet@2":""},"deviceTypes":{"desktop":true,"tablet":true,"phone":true}},"sap.ui5":{"flexEnabled":true,"dependencies":{"minUI5Version":"1.123.1","libs":{"sap.m":{},"sap.ui.core":{},"sap.f":{},"sap.suite.ui.generic.template":{},"sap.ui.comp":{},"sap.ui.generic.app":{},"sap.ui.table":{},"sap.ushell":{}}},"contentDensities":{"compact":true,"cozy":true},"models":{"i18n":{"type":"sap.ui.model.resource.ResourceModel","settings":{"bundleName":"adminmodule.i18n.i18n"}}},"resources":{"css":[{"uri":"css/style.css"}]},"routing":{"config":{"routerClass":"sap.m.routing.Router","viewType":"XML","async":true,"viewPath":"adminmodule.view","controlAggregation":"pages","controlId":"app","clearControlAggregation":false},"routes":[{"name":"RouteMaster","pattern":":?query:","target":["TargetMaster"]}],"targets":{"TargetMaster":{"viewType":"XML","transition":"slide","clearControlAggregation":false,"viewId":"Master","viewName":"Master"}}},"rootView":{"viewName":"adminmodule.view.App","type":"XML","async":true,"id":"App"}}}',
	"adminmodule/model/models.js":function(){
sap.ui.define(["sap/ui/model/json/JSONModel","sap/ui/Device"],function(e,n){"use strict";return{createDeviceModel:function(){var i=new e(n);i.setDefaultBindingMode("OneWay");return i}}});
},
	"adminmodule/view/App.view.xml":'<mvc:View controllerName="adminmodule.controller.App"\n    xmlns:html="http://www.w3.org/1999/xhtml"\n    xmlns:mvc="sap.ui.core.mvc" displayBlock="true"\n    xmlns="sap.m"><App id="app"></App></mvc:View>\n',
	"adminmodule/view/Master.view.xml":'<mvc:View controllerName="adminmodule.controller.Master"\n    xmlns:mvc="sap.ui.core.mvc" displayBlock="true"\n    xmlns="sap.m"><Page id="page" title="{i18n>title}"><content /></Page></mvc:View>\n'
});
//# sourceMappingURL=Component-preload.js.map
