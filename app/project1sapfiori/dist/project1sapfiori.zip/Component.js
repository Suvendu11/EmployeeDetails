sap.ui.define(["sap/fe/core/AppComponent"],function(e){"use strict";return e.extend("project1sapfiori.Component",{metadata:{manifest:"json"}})});
//# sourceMappingURL=Component.js.map